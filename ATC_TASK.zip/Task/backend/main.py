#!/usr/bin/env python3
"""
ATC Visualizer backend — pure stdlib + requests.
Usage: python3 main.py [port]   (default port: 8000)
"""
import csv
import io
import json
import sys
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

import requests

OPENSKY_BASE = "https://opensky-network.org/api"
AIRPORTS_CSV_URL = "https://ourairports.com/data/airports.csv"

_airports_cache = None
_airports_cache_time = 0.0
AIRPORTS_CACHE_TTL = 3600


# ── helpers ──────────────────────────────────────────────────────────────────

def _parse_state(state):
    return {
        "icao24": state[0],
        "callsign": (state[1] or "").strip(),
        "origin_country": (state[2] or "Unknown").strip(),
        "longitude": state[5],
        "latitude": state[6],
        "baro_altitude": state[7],
        "on_ground": state[8],
        "velocity": state[9],
        "heading": state[10],
        "vertical_rate": state[11],
        "geo_altitude": state[13],
        "squawk": state[14],
    }


def _load_airports():
    global _airports_cache, _airports_cache_time
    if _airports_cache and (time.time() - _airports_cache_time) < AIRPORTS_CACHE_TTL:
        return _airports_cache

    resp = requests.get(AIRPORTS_CSV_URL, timeout=30)
    resp.raise_for_status()

    reader = csv.DictReader(io.StringIO(resp.text))
    airports = []
    for row in reader:
        if row.get("type") not in ("large_airport", "medium_airport"):
            continue
        ident = (row.get("ident") or "").strip()
        if not ident:
            continue
        try:
            lat = float(row["latitude_deg"]) if row.get("latitude_deg") else None
            lon = float(row["longitude_deg"]) if row.get("longitude_deg") else None
        except (ValueError, KeyError):
            lat = lon = None
        airports.append({
            "ident": ident,
            "name": row.get("name", ""),
            "country": row.get("iso_country", ""),
            "municipality": row.get("municipality", ""),
            "latitude": lat,
            "longitude": lon,
            "type": row.get("type", ""),
        })

    _airports_cache = airports
    _airports_cache_time = time.time()
    return airports


# ── route handlers ────────────────────────────────────────────────────────────

def handle_aircraft_all(_params):
    resp = requests.get(f"{OPENSKY_BASE}/states/all", timeout=30)
    if not resp.ok:
        return 502, {"error": "OpenSky API unavailable", "status": resp.status_code}

    data = resp.json()
    states = data.get("states") or []

    grouped = {}
    for state in states:
        if state is None:
            continue
        country = (state[2] or "Unknown").strip()
        grouped.setdefault(country, []).append(_parse_state(state))

    countries = [
        {"country": c, "count": len(ac), "aircraft": ac}
        for c, ac in sorted(grouped.items())
    ]
    total = sum(len(ac) for ac in grouped.values())
    return 200, {"timestamp": data.get("time"), "total": total, "countries": countries}


def handle_aircraft_one(icao24):
    resp = requests.get(
        f"{OPENSKY_BASE}/states/all",
        params={"icao24": icao24.lower()},
        timeout=30,
    )
    if not resp.ok:
        return 502, {"error": "OpenSky error"}

    states = (resp.json().get("states") or [])
    if not states:
        return 404, {"error": "Aircraft not found or not airborne"}
    return 200, _parse_state(states[0])


def handle_airports(params):
    airports = _load_airports()
    country = params.get("country", [None])[0]
    if country:
        airports = [a for a in airports if a["country"].upper() == country.upper()]
    return 200, {"airports": airports}


def handle_airport_countries(_params):
    airports = _load_airports()
    countries = sorted({a["country"] for a in airports if a["country"]})
    return 200, {"countries": countries}


def handle_departures(params):
    airport_list = params.get("airport", [])
    if not airport_list:
        return 400, {"error": "airport query param required"}
    airport = airport_list[0].upper()

    now = int(time.time())
    begin = now - 1200  # 20 min ago

    resp = requests.get(
        f"{OPENSKY_BASE}/flights/departure",
        params={"airport": airport, "begin": begin, "end": now},
        timeout=30,
    )

    if resp.status_code in (400, 404):
        return 200, {"airport": airport, "flights": [], "window_minutes": 20,
                     "note": "No departure data for this airport/time window"}
    if not resp.ok:
        return 502, {"error": "OpenSky departure API error", "status": resp.status_code}

    flights = resp.json() or []
    result = [
        {
            "icao24": f.get("icao24", ""),
            "callsign": (f.get("callsign") or "").strip(),
            "departure_airport": f.get("estDepartureAirport", ""),
            "arrival_airport": f.get("estArrivalAirport", ""),
            "first_seen": f.get("firstSeen"),
            "last_seen": f.get("lastSeen"),
        }
        for f in flights
    ]
    return 200, {"airport": airport, "flights": result, "window_minutes": 20}


# ── HTTP server ───────────────────────────────────────────────────────────────

ROUTES = {
    "/api/aircraft":          handle_aircraft_all,
    "/api/airports":          handle_airports,
    "/api/airports/countries": handle_airport_countries,
    "/api/departures":        handle_departures,
    "/health":                lambda _: (200, {"status": "ok"}),
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[{self.address_string()}] {fmt % args}")

    def _send(self, status, body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/")
        params = urllib.parse.parse_qs(parsed.query)

        # /api/aircraft/<icao24>
        if path.startswith("/api/aircraft/"):
            icao24 = path[len("/api/aircraft/"):]
            if icao24:
                try:
                    status, body = handle_aircraft_one(icao24)
                except Exception as e:
                    self._send(500, {"error": str(e)})
                    return
                self._send(status, body)
                return

        handler = ROUTES.get(path)
        if handler is None:
            self._send(404, {"error": "Not found"})
            return

        try:
            status, body = handler(params)
        except Exception as e:
            print(f"Error handling {path}: {e}")
            self._send(500, {"error": str(e)})
            return

        self._send(status, body)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    server = HTTPServer(("0.0.0.0", port), Handler)
    print(f"ATC Visualizer API running on http://0.0.0.0:{port}")
    print("Endpoints:")
    for r in ROUTES:
        print(f"  GET {r}")
    print("  GET /api/aircraft/<icao24>")
    server.serve_forever()
