import React, { useState } from 'react';
import AircraftOverview from './components/AircraftOverview';
import TrafficVolume from './components/TrafficVolume';
import DepartureForecast from './components/DepartureForecast';
import AircraftMap from './components/AircraftMap';
import './App.css';

const TABS = [
  { id: 'overview', label: '✈ Aircraft Overview', desc: 'All aircraft grouped by country · auto-refresh 10s' },
  { id: 'traffic', label: '📊 Traffic Volume', desc: 'Aircraft count per country' },
  { id: 'departures', label: '🛫 Departure Forecast', desc: 'Departures from selected airport · last 20 min' },
  { id: 'map', label: '🗺 Aircraft Map', desc: 'Live positions on map' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [mapTarget, setMapTarget] = useState(null);

  function openMap(aircraft) {
    setMapTarget(aircraft);
    setActiveTab('map');
  }

  return (
    <div className="app">
      <header className="app-header">
        <div className="app-title">
          <span className="app-logo">✈</span>
          <div>
            <h1>ATC Visualizer</h1>
            <p>Real-time global air traffic monitoring</p>
          </div>
        </div>
      </header>

      <nav className="tab-nav">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            className={`tab-btn${activeTab === tab.id ? ' active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="tab-label">{tab.label}</span>
            <span className="tab-desc">{tab.desc}</span>
          </button>
        ))}
      </nav>

      <main className="app-main">
        {activeTab === 'overview' && <AircraftOverview onOpenMap={openMap} />}
        {activeTab === 'traffic' && <TrafficVolume />}
        {activeTab === 'departures' && <DepartureForecast />}
        {activeTab === 'map' && <AircraftMap target={mapTarget} onClearTarget={() => setMapTarget(null)} />}
      </main>
    </div>
  );
}
