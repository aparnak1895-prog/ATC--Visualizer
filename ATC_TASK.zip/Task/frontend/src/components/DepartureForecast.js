import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

function formatTime(unix) {
  if (!unix) return '—';
  return new Date(unix * 1000).toLocaleTimeString();
}

export default function DepartureForecast() {
  const [countries, setCountries] = useState([]);
  const [airports, setAirports] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedAirport, setSelectedAirport] = useState('');
  const [flights, setFlights] = useState(null);
  const [loadingCountries, setLoadingCountries] = useState(true);
  const [loadingAirports, setLoadingAirports] = useState(false);
  const [loadingFlights, setLoadingFlights] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await axios.get('/api/airports/countries');
        setCountries(res.data.countries);
      } catch (e) {
        setError('Failed to load countries');
      } finally {
        setLoadingCountries(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!selectedCountry) { setAirports([]); return; }
    setLoadingAirports(true);
    setSelectedAirport('');
    setFlights(null);
    (async () => {
      try {
        const res = await axios.get('/api/airports', { params: { country: selectedCountry } });
        setAirports(res.data.airports);
      } catch (e) {
        setError('Failed to load airports');
      } finally {
        setLoadingAirports(false);
      }
    })();
  }, [selectedCountry]);

  const fetchDepartures = useCallback(async () => {
    if (!selectedAirport) return;
    setLoadingFlights(true);
    setError(null);
    try {
      const res = await axios.get('/api/departures', { params: { airport: selectedAirport } });
      setFlights(res.data);
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to fetch departures');
      setFlights(null);
    } finally {
      setLoadingFlights(false);
    }
  }, [selectedAirport]);

  useEffect(() => {
    fetchDepartures();
  }, [fetchDepartures]);

  return (
    <div>
      <div className="card" style={{ padding: '14px 20px', marginBottom: 16 }}>
        <div className="section-title">Departure Forecast</div>
        <div className="section-sub">
          Aircraft that departed from the selected airport in the last 20 minutes (OpenSky Network data)
        </div>
      </div>

      <div className="card">
        <div className="controls-row">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: '0.74rem', color: '#7d8590', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Country</label>
            <select
              className="select-input"
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              disabled={loadingCountries}
            >
              <option value="">— select country —</option>
              {countries.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: '0.74rem', color: '#7d8590', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Airport</label>
            <select
              className="select-input"
              value={selectedAirport}
              onChange={(e) => setSelectedAirport(e.target.value)}
              disabled={!selectedCountry || loadingAirports}
              style={{ minWidth: 280 }}
            >
              <option value="">— select airport —</option>
              {airports.map((a) => (
                <option key={a.ident} value={a.ident}>
                  {a.ident} · {a.name}{a.municipality ? ` (${a.municipality})` : ''}
                </option>
              ))}
            </select>
          </div>

          {selectedAirport && (
            <button
              className="btn btn-primary"
              style={{ alignSelf: 'flex-end' }}
              onClick={fetchDepartures}
              disabled={loadingFlights}
            >
              {loadingFlights ? 'Loading…' : 'Refresh'}
            </button>
          )}
        </div>

        {loadingAirports && <div className="status-bar"><span className="spinner" />Loading airports…</div>}

        {error && <div className="error-box" style={{ marginTop: 12 }}>{error}</div>}

        {!selectedCountry && (
          <div className="empty-state">Select a country and airport to see departure data.</div>
        )}

        {selectedCountry && !selectedAirport && !loadingAirports && (
          <div className="empty-state">
            {airports.length === 0
              ? 'No large/medium airports found for this country.'
              : 'Select an airport above.'}
          </div>
        )}

        {flights && (
          <div style={{ marginTop: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
              <span style={{ fontSize: '0.85rem', color: '#7d8590' }}>
                Airport <strong style={{ color: '#e6edf3' }}>{flights.airport}</strong> · last {flights.window_minutes} minutes
              </span>
              {flights.note && <span className="badge badge-gray">{flights.note}</span>}
              <span className="badge badge-blue">{flights.flights.length} departures</span>
            </div>

            {flights.flights.length === 0 ? (
              <div className="empty-state">No departures recorded in the last 20 minutes.</div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>ICAO24</th>
                      <th>Callsign</th>
                      <th>Destination</th>
                      <th>Departed</th>
                      <th>Last seen</th>
                    </tr>
                  </thead>
                  <tbody>
                    {flights.flights.map((f, i) => (
                      <tr key={f.icao24 + i}>
                        <td className="mono">{f.icao24 || '—'}</td>
                        <td className="mono">{f.callsign || '—'}</td>
                        <td>{f.arrival_airport || '—'}</td>
                        <td>{formatTime(f.first_seen)}</td>
                        <td>{formatTime(f.last_seen)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
