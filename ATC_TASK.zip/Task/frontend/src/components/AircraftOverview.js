import React, { useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';

const REFRESH_SEC = 10;

export default function AircraftOverview({ onOpenMap }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [countdown, setCountdown] = useState(REFRESH_SEC);
  const [expanded, setExpanded] = useState({});
  const [search, setSearch] = useState('');
  const countdownRef = useRef(null);

  const fetchData = useCallback(async () => {
    try {
      setError(null);
      const res = await axios.get('/api/aircraft');
      setData(res.data);
      setCountdown(REFRESH_SEC);
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to fetch aircraft data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, REFRESH_SEC * 1000);
    return () => clearInterval(interval);
  }, [fetchData]);

  useEffect(() => {
    countdownRef.current = setInterval(() => {
      setCountdown((c) => (c <= 1 ? REFRESH_SEC : c - 1));
    }, 1000);
    return () => clearInterval(countdownRef.current);
  }, []);

  function toggleCountry(country) {
    setExpanded((prev) => ({ ...prev, [country]: !prev[country] }));
  }

  const filteredCountries = data?.countries?.filter((c) =>
    c.country.toLowerCase().includes(search.toLowerCase())
  ) || [];

  return (
    <div>
      <div className="card" style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <div className="section-title">Real-Time Aircraft Overview</div>
            <div className="section-sub">All airborne aircraft grouped by origin country</div>
          </div>
          {data && (
            <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
              <span className="badge badge-blue">{data.total?.toLocaleString()} aircraft</span>
              <span className="badge badge-gray">{data.countries?.length} countries</span>
            </div>
          )}
        </div>
      </div>

      <div className="status-bar">
        <span className="status-dot" />
        <span>Live data from OpenSky Network</span>
        <span style={{ marginLeft: 'auto' }}>
          {loading ? (
            <><span className="spinner" />Refreshing…</>
          ) : (
            `Next refresh in ${countdown}s`
          )}
        </span>
        <button className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '0.75rem' }} onClick={fetchData}>
          Refresh now
        </button>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="controls-row">
        <input
          className="select-input"
          style={{ minWidth: 260 }}
          placeholder="Filter countries…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <span style={{ fontSize: '0.78rem', color: '#7d8590' }}>
          Showing {filteredCountries.length} of {data?.countries?.length || 0} countries
        </span>
      </div>

      {filteredCountries.length === 0 && !loading && !error && (
        <div className="empty-state">No countries match your filter.</div>
      )}

      {filteredCountries.map((group) => (
        <div key={group.country} className="card" style={{ marginBottom: 8, padding: 0, overflow: 'hidden' }}>
          <button
            onClick={() => toggleCountry(group.country)}
            style={{
              width: '100%',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '12px 20px',
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              color: '#e6edf3',
            }}
          >
            <span style={{ fontSize: '0.9rem', transform: expanded[group.country] ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s', display: 'inline-block' }}>▶</span>
            <span style={{ fontWeight: 600, fontSize: '0.9rem', flex: 1, textAlign: 'left' }}>{group.country}</span>
            <span className="badge badge-blue">{group.count}</span>
          </button>

          {expanded[group.country] && (
            <div style={{ borderTop: '1px solid #30363d', overflowX: 'auto' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ICAO24</th>
                    <th>Callsign</th>
                    <th>Altitude (m)</th>
                    <th>Speed (m/s)</th>
                    <th>Heading °</th>
                    <th>Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {group.aircraft.map((ac) => (
                    <tr key={ac.icao24}>
                      <td className="mono">{ac.icao24}</td>
                      <td className="mono">{ac.callsign || '—'}</td>
                      <td>{ac.baro_altitude != null ? Math.round(ac.baro_altitude) : '—'}</td>
                      <td>{ac.velocity != null ? Math.round(ac.velocity) : '—'}</td>
                      <td>{ac.heading != null ? Math.round(ac.heading) : '—'}</td>
                      <td>
                        <span className={`badge ${ac.on_ground ? 'badge-gray' : 'badge-green'}`}>
                          {ac.on_ground ? 'On ground' : 'Airborne'}
                        </span>
                      </td>
                      <td>
                        {ac.latitude != null && ac.longitude != null && (
                          <button
                            className="btn btn-secondary"
                            style={{ padding: '3px 8px', fontSize: '0.72rem' }}
                            onClick={() => onOpenMap(ac)}
                          >
                            Map
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
