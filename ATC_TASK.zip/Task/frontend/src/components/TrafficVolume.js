import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const BAR_COLORS = ['#388bfd', '#3fb950', '#e3b341', '#f85149', '#a371f7', '#39d353'];

export default function TrafficVolume() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('count');

  const fetchData = useCallback(async () => {
    try {
      setError(null);
      const res = await axios.get('/api/aircraft');
      setData(res.data);
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading) return <div className="status-bar"><span className="spinner" />Loading traffic data…</div>;
  if (error) return <div className="error-box">{error}</div>;

  const countries = (data?.countries || [])
    .filter((c) => c.country.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => sortBy === 'count' ? b.count - a.count : a.country.localeCompare(b.country));

  const maxCount = countries[0]?.count || 1;
  const top10 = [...(data?.countries || [])].sort((a, b) => b.count - a.count).slice(0, 10);

  return (
    <div>
      <div className="card" style={{ padding: '14px 20px', marginBottom: 16 }}>
        <div className="section-title">Traffic Volume by Country</div>
        <div className="section-sub">Current airborne aircraft count per origin country</div>
      </div>

      {/* Top-10 bar chart */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ fontSize: '0.85rem', fontWeight: 600, marginBottom: 16, color: '#7d8590' }}>TOP 10 COUNTRIES</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {top10.map((c, i) => {
            const pct = (c.count / top10[0].count) * 100;
            const color = BAR_COLORS[i % BAR_COLORS.length];
            return (
              <div key={c.country} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 180, fontSize: '0.82rem', color: '#c9d1d9', textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {c.country}
                </div>
                <div style={{ flex: 1, background: '#21262d', borderRadius: 4, height: 18, overflow: 'hidden' }}>
                  <div
                    style={{
                      width: `${pct}%`,
                      height: '100%',
                      background: color,
                      borderRadius: 4,
                      transition: 'width 0.5s',
                      display: 'flex',
                      alignItems: 'center',
                      paddingLeft: 6,
                    }}
                  >
                    <span style={{ fontSize: '0.7rem', color: '#fff', fontWeight: 700 }}>{c.count}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Full table */}
      <div className="card">
        <div className="controls-row">
          <input
            className="select-input"
            placeholder="Filter countries…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select className="select-input" value={sortBy} onChange={(e) => setSortBy(e.target.value)} style={{ minWidth: 140 }}>
            <option value="count">Sort by count</option>
            <option value="name">Sort by name</option>
          </select>
          <button className="btn btn-secondary" onClick={fetchData}>Refresh</button>
          <span style={{ fontSize: '0.78rem', color: '#7d8590', marginLeft: 'auto' }}>
            {countries.length} countries · {data?.total?.toLocaleString()} total aircraft
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ width: 40 }}>#</th>
                <th>Country</th>
                <th>Aircraft</th>
                <th>Share</th>
                <th>Bar</th>
              </tr>
            </thead>
            <tbody>
              {countries.map((c, i) => {
                const share = data?.total ? ((c.count / data.total) * 100).toFixed(1) : 0;
                const barPct = (c.count / maxCount) * 100;
                return (
                  <tr key={c.country}>
                    <td style={{ color: '#7d8590' }}>{i + 1}</td>
                    <td style={{ fontWeight: 500 }}>{c.country}</td>
                    <td><span className="badge badge-blue">{c.count.toLocaleString()}</span></td>
                    <td style={{ color: '#7d8590' }}>{share}%</td>
                    <td style={{ minWidth: 120 }}>
                      <div style={{ background: '#21262d', borderRadius: 3, height: 8 }}>
                        <div style={{ width: `${barPct}%`, height: '100%', background: '#388bfd', borderRadius: 3 }} />
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
