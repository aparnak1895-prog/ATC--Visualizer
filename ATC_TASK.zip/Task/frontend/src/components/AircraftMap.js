import React, { useState, useEffect, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';

// Fix default marker icon paths broken by webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const planeIcon = (heading) =>
  L.divIcon({
    className: '',
    html: `<div style="font-size:18px;transform:rotate(${heading ?? 0}deg);line-height:1;">✈</div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
  });

const highlightIcon = (heading) =>
  L.divIcon({
    className: '',
    html: `<div style="font-size:22px;transform:rotate(${heading ?? 0}deg);line-height:1;filter:drop-shadow(0 0 6px #388bfd);">✈</div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });

function FlyTo({ target }) {
  const map = useMap();
  useEffect(() => {
    if (target?.latitude != null && target?.longitude != null) {
      map.flyTo([target.latitude, target.longitude], 8, { duration: 1.5 });
    }
  }, [target, map]);
  return null;
}

export default function AircraftMap({ target, onClearTarget }) {
  const [allAircraft, setAllAircraft] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [searchResult, setSearchResult] = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [showAll, setShowAll] = useState(false);

  const fetchAll = useCallback(async () => {
    try {
      setError(null);
      const res = await axios.get('/api/aircraft');
      const flat = (res.data.countries || []).flatMap((c) => c.aircraft);
      setAllAircraft(flat.filter((a) => a.latitude != null && a.longitude != null));
    } catch (e) {
      setError('Failed to load aircraft positions');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  async function searchAircraft() {
    const icao = search.trim().toLowerCase();
    if (!icao) return;
    setSearchLoading(true);
    try {
      const res = await axios.get(`/api/aircraft/${icao}`);
      setSearchResult(res.data);
    } catch (e) {
      setSearchResult(null);
      setError(e.response?.status === 404 ? `Aircraft ${icao} not found or not airborne` : 'Search failed');
    } finally {
      setSearchLoading(false);
    }
  }

  const focusTarget = searchResult || target;

  // Show a sampled subset when showAll is off (performance)
  const displayed = showAll ? allAircraft : allAircraft.slice(0, 500);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 160px)', gap: 12 }}>
      {/* Controls */}
      <div className="card" style={{ padding: '12px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div className="section-title">Aircraft Map</div>
            <div className="section-sub">Live aircraft positions · OpenStreetMap</div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input
              className="select-input"
              style={{ minWidth: 200 }}
              placeholder="Search ICAO24 (e.g. 3c6444)"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchAircraft()}
            />
            <button className="btn btn-primary" onClick={searchAircraft} disabled={searchLoading || !search.trim()}>
              {searchLoading ? '…' : 'Go'}
            </button>
          </div>
          {focusTarget && (
            <button
              className="btn btn-secondary"
              onClick={() => { setSearchResult(null); onClearTarget(); }}
            >
              Clear focus
            </button>
          )}
          <button
            className="btn btn-secondary"
            onClick={() => { setShowAll((v) => !v); }}
          >
            {showAll ? `All ${allAircraft.length}` : `Top 500`}
          </button>
          <button className="btn btn-secondary" onClick={fetchAll}>Refresh</button>
        </div>

        {error && <div className="error-box" style={{ marginTop: 8 }}>{error}</div>}

        {focusTarget && (
          <div style={{ marginTop: 10, padding: '10px 14px', background: '#1c2128', borderRadius: 6, fontSize: '0.82rem', display: 'flex', gap: 20, flexWrap: 'wrap' }}>
            <span><strong style={{ color: '#7d8590' }}>ICAO24</strong> <span className="mono">{focusTarget.icao24}</span></span>
            <span><strong style={{ color: '#7d8590' }}>Callsign</strong> {focusTarget.callsign || '—'}</span>
            <span><strong style={{ color: '#7d8590' }}>Country</strong> {focusTarget.origin_country || '—'}</span>
            <span><strong style={{ color: '#7d8590' }}>Alt</strong> {focusTarget.baro_altitude != null ? `${Math.round(focusTarget.baro_altitude)} m` : '—'}</span>
            <span><strong style={{ color: '#7d8590' }}>Speed</strong> {focusTarget.velocity != null ? `${Math.round(focusTarget.velocity)} m/s` : '—'}</span>
            <span><strong style={{ color: '#7d8590' }}>Heading</strong> {focusTarget.heading != null ? `${Math.round(focusTarget.heading)}°` : '—'}</span>
          </div>
        )}
      </div>

      {/* Map */}
      {loading ? (
        <div className="status-bar"><span className="spinner" />Loading aircraft positions…</div>
      ) : (
        <div style={{ flex: 1, borderRadius: 8, overflow: 'hidden', border: '1px solid #30363d' }}>
          <MapContainer
            center={[20, 0]}
            zoom={2}
            style={{ height: '100%', width: '100%', background: '#0d1117' }}
          >
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/">CARTO</a>'
              maxZoom={19}
            />

            {displayed.map((ac) => {
              const isFocus = focusTarget?.icao24 === ac.icao24;
              return (
                <Marker
                  key={ac.icao24}
                  position={[ac.latitude, ac.longitude]}
                  icon={isFocus ? highlightIcon(ac.heading) : planeIcon(ac.heading)}
                  zIndexOffset={isFocus ? 1000 : 0}
                >
                  <Popup>
                    <div style={{ minWidth: 180, fontFamily: 'monospace', fontSize: '12px', lineHeight: 1.6 }}>
                      <div><strong>ICAO24:</strong> {ac.icao24}</div>
                      <div><strong>Callsign:</strong> {ac.callsign || '—'}</div>
                      <div><strong>Country:</strong> {ac.origin_country}</div>
                      <div><strong>Altitude:</strong> {ac.baro_altitude != null ? `${Math.round(ac.baro_altitude)} m` : '—'}</div>
                      <div><strong>Speed:</strong> {ac.velocity != null ? `${Math.round(ac.velocity)} m/s` : '—'}</div>
                      <div><strong>Heading:</strong> {ac.heading != null ? `${Math.round(ac.heading)}°` : '—'}</div>
                      <div><strong>Status:</strong> {ac.on_ground ? 'On ground' : 'Airborne'}</div>
                    </div>
                  </Popup>
                </Marker>
              );
            })}

            {focusTarget?.latitude != null && <FlyTo target={focusTarget} />}
          </MapContainer>
        </div>
      )}

      <div style={{ fontSize: '0.74rem', color: '#7d8590', textAlign: 'right' }}>
        Showing {displayed.length} of {allAircraft.length} aircraft with known positions
        {!showAll && allAircraft.length > 500 && ' · click "Top 500" to toggle all'}
      </div>
    </div>
  );
}
