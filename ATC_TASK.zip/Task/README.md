# ATC Visualizer — AWS VBO Code Challenge

Real-time global air traffic monitoring app built with **React** (frontend) and **Python** (backend).

---

## User Stories Implemented

| # | Story | Implementation |
|---|-------|---------------|
| 1 | View all aircraft grouped by origin country, refresh every 10 s | Aircraft Overview tab — collapsible country groups, live countdown |
| 2 | Check current aircraft count per country | Traffic Volume tab — bar chart + sortable table |
| 3 | List aircraft departing from selected airport (last 20 min) | Departure Forecast tab — country → airport drill-down |
| 4 | View individual aircraft position on a map | Aircraft Map tab — Leaflet/OSM, ICAO24 search, click-to-map from Overview |

---

## Tech Stack

- **Frontend** — React 18, react-leaflet (OpenStreetMap), axios, Create React App  
- **Backend** — Python 3 (stdlib `http.server` + `requests`), no framework required  
- **Data** — OpenSky Network REST API, OurAirports.com CSV

---

## Prerequisites

- Python 3.8+ with `requests` installed  
- Node.js 18+

Check if `requests` is available:
```bash
python3 -c "import requests; print(requests.__version__)"
```

If not, install it:
```bash
pip install requests          # or
pip3 install requests
```

---

## Quick Start

```bash
# 1. Start the backend (port 8000)
cd backend
python3 main.py

# 2. In a second terminal — start the frontend (port 3000)
cd frontend
npm install   # first time only
npm start
```

Open **http://localhost:3000** in your browser.

Or use the combined start script:
```bash
chmod +x start.sh
./start.sh
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/aircraft` | All aircraft grouped by origin country |
| GET | `/api/aircraft/:icao24` | Single aircraft by ICAO24 |
| GET | `/api/airports?country=DE` | Airports (optionally filtered by ISO country code) |
| GET | `/api/airports/countries` | Distinct ISO country codes with airports |
| GET | `/api/departures?airport=EDDF` | Departures in the last 20 minutes |
| GET | `/health` | Health check |

---

## Project Structure

```
├── backend/
│   ├── main.py          # Python HTTP server (stdlib + requests)
│   └── requirements.txt
└── frontend/
    ├── src/
    │   ├── App.js
    │   └── components/
    │       ├── AircraftOverview.js   # User story 1
    │       ├── TrafficVolume.js      # User story 2
    │       ├── DepartureForecast.js  # User story 3
    │       └── AircraftMap.js        # User story 4
    └── package.json
```

---

## Notes

- **Map**: Uses Leaflet + OpenStreetMap (dark CARTO tiles) instead of Google Maps — no API key required.
- **Departures**: OpenSky Network only provides historical departure data; the endpoint queries the last 20 minutes as a real-time proxy.
- **Rate limiting**: OpenSky's anonymous tier may throttle requests; authenticated requests are supported but not required.
- **Airport data**: Cached server-side for 1 hour from OurAirports.com CSV (large + medium airports only).
