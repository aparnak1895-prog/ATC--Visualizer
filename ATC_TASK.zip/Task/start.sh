#!/bin/bash
set -e

# Start the ATC Visualizer (backend + frontend dev server)

echo "=== Starting ATC Visualizer ==="

# Backend
echo "Starting Python backend on http://localhost:8000"
cd "$(dirname "$0")/backend"
python3 main.py 8000 &
BACKEND_PID=$!

# Frontend
echo "Starting React frontend on http://localhost:3000"
cd "$(dirname "$0")/frontend"
npm start &
FRONTEND_PID=$!

# Cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT INT TERM

echo ""
echo "App running at http://localhost:3000"
echo "API running at http://localhost:8000"
echo "Press Ctrl+C to stop."
wait
